//
//  FavouriteMovie+CoreDataClass.swift
//  Movie_App
//
//  Created by Bahadir Alacan on 8.08.2022.
//
//

import Foundation
import CoreData

@objc(FavouriteMovie)
public class FavouriteMovie: NSManagedObject {

}
